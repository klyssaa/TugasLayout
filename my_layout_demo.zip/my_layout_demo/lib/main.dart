import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Web Layout Demo',
        home: Scaffold(
          appBar: AppBar(
            title: const Text('Flutter Web Layout Demo'),
          ),
          body: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Icon(Icons.favorite, color: Colors.red),
                  Icon(Icons.star, color: Colors.yellow),
                  Icon(Icons.share, color: Colors.blue),
                ],
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  'This is an example of basic layout in Flutter Web.',
                  style: TextStyle(fontSize: 18),
                ),
              ),
              Image.network(
                'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl.jpg',
                height: 200,
              ),
            ],
          ),
        ));
  }
}
