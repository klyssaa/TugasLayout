package com.example.my_layout_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
